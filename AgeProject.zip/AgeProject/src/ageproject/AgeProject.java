
package ageproject;

public class AgeProject {

    public static void main(String[] args) {
       Leapyear L =new Leapyear();
       Daycount D=new Daycount();
       D.Birth_day =7;
       L.Birth_month=12;
       L.Birth_year=1999;
       D.current_day =27;
       L.current_month =9;
       L.current_year =2022;
       L.display();
       
       D.Birth_month=L.Birth_month;
       D.Birth_year=L.Birth_year;
       D.current_month=L.current_month;
       
       D.current_year=L.current_year;
  
       
        int d =30;
        int m = 12;
        if(D.current_day>D.Birth_day){
            if((D.Birth_year %4 == 0)&&(D.Birth_year %100!=0)||(D.Birth_year %400==0)){
           int day = (D.current_day+1)-D.Birth_day;
            System.out.println("Day :"+day);
              }
            else {
            int  day = D.current_day-D.Birth_day;
            System.out.println("Day :"+day);
            }
         if(L.current_month>L.Birth_month){
                int month =L.current_month- L.Birth_month;
                System.out.println("Month :"+month);
         if(D.current_year>D.Birth_year){
                 int year = D.current_year-D.Birth_year;
                System.out.println("Year :"+year);
            }  
         
            } 
          else if(L.current_month<L.Birth_month){
                 int month = (m+L.current_month)-L.Birth_month;
                System.out.println("Month :"+month);
            if(D.current_year>D.Birth_year){
                int year = (D.current_year-1)-D.Birth_year;
                System.out.println("Year :"+year);
            }
          }  
          else if(L.current_month==L.Birth_month){
              System.out.println("Month :0");
             if(D.current_year>D.Birth_year){
               int year = D.current_year-D.Birth_year;
                System.out.println("Year :"+year);
          }
             else if(D.current_year==D.Birth_year){
                 System.out.println("Year :0");
             }
                 
             } 
          

        }
       else if (D.current_day<D.Birth_day){
           if((D.Birth_year %4 == 0)&&(D.Birth_year %100!=0)||(D.Birth_year %400==0)){
           int day = (d+D.current_day+1)-D.Birth_day;
            System.out.println("Day :"+day);
           }
            else {
            int day = (d+D.current_day)-D.Birth_day;
            System.out.println("Day :"+day);
                    }
        if(D.current_month>D.Birth_month){
                int month =(D.current_month-1)-D. Birth_month;
                System.out.println("Month :"+month);
             if(D.current_year>D.Birth_year){
                int year = (D.current_year-D.Birth_year);
                System.out.println("Year :"+year);
            } 
            }
            else if(L.current_month<L.Birth_month){
                int month = (m+L.current_month-1)-L.Birth_month;
                System.out.println("Month :"+month);
            if(D.current_year>D.Birth_year){
              int  year = (D.current_year-1)-D.Birth_year;
                System.out.println("Year :"+year);
            } 
            
        
        }
            else if(L.current_month==L.Birth_month){
               int month = (m+L.current_month-1)-L.Birth_month;
               System.out.println("Month :"+month);
            }
            
    }
       else if(D.current_day==D.Birth_day){
           System.out.println("Day :0");
          if(L.current_month==L.Birth_month){
              System.out.println("Month :0");
          if(D.current_year==D.Birth_year){
              System.out.println(" year:0");
          }
          else if(D.current_year>D.Birth_year){
                int year = D.current_year-D.Birth_year;
                System.out.println("Year :"+year);
          
       }
          }
          else if(L.current_month>L.Birth_month){
                int month =D.current_month- D.Birth_month;
                System.out.println("Month :"+month);
         if(D.current_year>D.Birth_year){
               int year = D.current_year-D.Birth_year;
                System.out.println("Year :"+year);
            } 

          } 
        else if(L.current_month<L.Birth_month){
                int month = (m+L.current_month)-D.Birth_month;
                System.out.println("Month :"+month);
            if(D.current_year>D.Birth_year){
               int year = (D.current_year-1)-D.Birth_year;
                System.out.println("Year :"+year);
            }   

}
       }
             D.display();
    }
}
             
      
                
       
    
    

