
package ageproject;
public class Daycount extends Leapyear {
    int month[]={31,28,31,30,31,30,31,31,30,31,30,31};
    int Birth_day,current_day,t_m=month.length,j,sum=0,B_day=0,Total_day;
    
    Daycount(){
        super();
        this.Birth_day=-1;
        this.current_day=-1;
    }
    Daycount(int Birth_day ,int current_day){
        super();
        this.Birth_day=Birth_day;
        this.current_day=current_day;
        
    }
    int Daycount(){
        for (int i =Birth_year; i <=current_year; i++) {
            if(i==current_year){
                t_m=current_month;
            }
            for (j = Birth_month; j <t_m; j++) {
              sum =sum+month[j];
            }Birth_month=0;
           
        }
        return sum;
        
        
        
    }
    @Override
   void display(){
         B_day = month[Birth_month-1]-Birth_day;
         int C_day = month[current_month-1]-current_day;
         Total_day = (B_day+Daycount()+Leapyear())-C_day; 
       System.out.println("Total Day : " +Total_day);
        System.out.println("Total Week :"+Total_day/7);

   }
    
}
