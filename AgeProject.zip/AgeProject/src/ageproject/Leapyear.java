
package ageproject;

public class Leapyear {
    int month []= {31,28,31,30,31,30,31,31,30,31,30,31};
    int Birth_month,Birth_year,current_month,current_year,leapyear=0;
    Leapyear(){
        this.Birth_month =-1;
        this.Birth_year = -1;
        this.current_month= -1;
        this.current_year = -1;
        
    }
    Leapyear(int Birth_month,int Birth_year,int current_month,int current_year){
        this.Birth_month=Birth_month;
        this.Birth_year=Birth_year;
        this.current_month= current_month;
        this.current_year =current_year;
        
    }
    int Leapyear(){
        for (int i =Birth_year; i <=current_year; i++) {
           if(i%4==0 && i%100 !=0 || i%400==0 && Birth_month<=2 ){
            
                leapyear++;
           }Birth_month=0;
        }
        for (int i = current_year; i <=current_year; i++) {
               if(i%4==0 && i%100 !=0 || i%400 ==0 && current_month<=2){
               leapyear--; 
            } 
           }
       
        
        return leapyear;
    }
    void display(){
        
    }
    
}
